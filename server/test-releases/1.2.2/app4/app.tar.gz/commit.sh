#!/bin/bash

echo -n "pre-commit.sh: here is PCO_NEW_ARTIFACTS_PATHS:"

echo "$PCO_NEW_ARTIFACTS_PATHS"
echo -n "pre-commit.sh: exiting with code 1"

exit 1

