#!/bin/bash

echo "pre-commit.sh: doing sh stuff!"

echo "pre-commit.sh: FAIL"

exit 1

