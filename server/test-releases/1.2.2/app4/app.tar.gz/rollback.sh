#!/bin/bash

echo -n "rollback.sh: here is PCO_ROLLBACK_ARTIFACTS_PATHS:"
echo "$PCO_ROLLBACK_ARTIFACTS_PATHS"

echo "rollback.sh: SETTING PREV APP TO AUTORUN"

exit 0
