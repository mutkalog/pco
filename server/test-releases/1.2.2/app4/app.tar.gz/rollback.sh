#!/bin/bash

echo "SETTING PREV APP TO AUTORUN"
