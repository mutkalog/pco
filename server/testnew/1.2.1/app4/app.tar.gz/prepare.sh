#!/bin/bash

echo "prepare.sh: working!"
exit 0
