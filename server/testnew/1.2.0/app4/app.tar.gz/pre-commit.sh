#!/bin/bash

echo "pre-commit.sh: doing sh stuff!"

echo "pre-commit.sh: I am about to exit"

exit 0

